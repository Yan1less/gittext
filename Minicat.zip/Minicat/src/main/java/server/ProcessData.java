package server;

import java.io.*;

public class ProcessData {
    public static void changeFile(String fName,String serverName) throws Exception{
        //存入点之后的数据
        String filePath=fName;
        File file=new File(filePath);
        BufferedReader reader = null;
        BufferedWriter writer = null;

        String tempString = null;
        int line =1;
        reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
        writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file+".txt"),"UTF-8"));
        while ((tempString = reader.readLine()) != null) {


//            if (tempString!=null && tempString.length()>10 && tempString.substring(0,7).equals("package")){
//                  String[] split = tempString.split("\\.");
//                    String result = split[0] + "." + serverName + "." + split[1];
//
//            }
            if (line==1){
                String s = tempString.substring(0, tempString.length() - 1) + "."+serverName + ";";

                writer.write(s+"\n");
            }else {
                writer.write(tempString+"\n");
            }

            line++;
        }
        reader.close();
        writer.close();

        file.delete();
        File newFile = new File(file + ".txt");
        newFile.renameTo(new File(fName));


    }
    //测试主方法
    public static void main(String[] args) throws Exception{
        changeFile("E:\\IDEAProject\\Minicat\\src\\main\\java\\servlet\\demo2\\Demo2Servlet.java","server");
        System.out.println(" change OK... ");
    }
}