package server;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Minicat的主类
 */
public class Bootstrap {

    /**
     * 定义socket监听的端口号
     */
    private int port = 8080;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }


    /**
     * Minicat启动需要初始化展开的一些操作
     */
    public void start() throws Exception {

        // 加载解析相关的配置，web.xml
        loadServlet();


        // 定义一个线程池
        int corePoolSize = 10;
        int maximumPoolSize = 50;
        long keepAliveTime = 100L;
        TimeUnit unit = TimeUnit.SECONDS;
        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<>(50);
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        RejectedExecutionHandler handler = new ThreadPoolExecutor.AbortPolicy();


        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                corePoolSize,
                maximumPoolSize,
                keepAliveTime,
                unit,
                workQueue,
                threadFactory,
                handler
        );
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("=====>>>Minicat start on port：" + port);
        System.out.println("=========>>>>>>使用线程池进行多线程改造");
        /*
            多线程改造（使用线程池）
         */
        while (true) {

            Socket socket = serverSocket.accept();
            RequestProcessor requestProcessor = new RequestProcessor(socket, servletMap);
            //requestProcessor.start();
            threadPoolExecutor.execute(requestProcessor);
        }


    }


    private Map<String, HttpServlet> servletMap = new HashMap<String, HttpServlet>();

    /**
     * 加载解析web.xml，初始化Servlet
     */
    private void loadServlet() throws IOException {

        //获取workbase
        String workBase = getWorkBase().replaceAll("\\\\", "/");
        //把workbase里的xml和servlet包下的东西复制进resource和temp下
        String s = this.getClass().getResource("").getFile().substring(1);

        //copy目的地
        String xmlPath = s.substring(0, s.length() - 7) + "web-temp.xml";
        String javaPath = s.substring(0, s.length() - 22) + "src/main/java/servlet/";

        //copy原本地
        File file = new File(workBase);
        File[] filesName = file.listFiles();
        //只有文件名称
        for (int i = 0; i < filesName.length; i++) {

            String javaBase = workBase + "/" + filesName[i].getName() + "/" + "src/main/java/servlet";
            String xmlBase = workBase + "/" + filesName[i].getName() + "/" + "src/main/resources/web.xml";
            //复制xml
            copyFile(xmlBase, xmlPath, "");
            //复制java
            File javaFiles = new File(javaBase);
            File[] javaFilesName = javaFiles.listFiles();
            for (int j = 0; j < javaFilesName.length; j++) {
                //创建该路径
                createPathDir(javaPath + filesName[i].getName());
                //复制java，额外传入项目路径
                System.out.println(javaFilesName[j].getName());
                copyFile(javaBase + "/" + javaFilesName[j].getName(), javaPath + filesName[i].getName() + "/" + javaFilesName[j].getName(), filesName[i].getName());


            }
            //读取xml
            readXml("web-temp.xml", filesName[i].getName());


            //清除此次读取内容
//                    File file1 = new File("web-temp.xml");
//                    file1.delete();
//                    for (int j = 0; j < javaFilesName.length; j++) {
//                        File file2 = new File(javaPath + javaFilesName[j].getName());
//                        file2.delete();
//                    }


        }

        //分别读取所有的xml
//        readXml("web.xml");


    }

    private void createPathDir(String name) {
        File file = new File(name);
        if (!file.exists()) {//如果文件夹不存在
            file.mkdir();//创建文件夹
        }
    }

    private void readXml(String path, String service) {
        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream(path);
        SAXReader saxReader = new SAXReader();

        try {
            Document document = saxReader.read(resourceAsStream);
            Element rootElement = document.getRootElement();
            String server = rootElement.selectSingleNode("server").getStringValue();


            List<Element> selectNodes = rootElement.selectNodes("//servlet");
            for (int i = 0; i < selectNodes.size(); i++) {
                Element element = selectNodes.get(i);
                // <temp-name>lagou</temp-name>
                Element servletnameElement = (Element) element.selectSingleNode("servlet-name");
                String servletName = servletnameElement.getStringValue();
                // <temp-class>server.LagouServlet</temp-class>
                Element servletclassElement = (Element) element.selectSingleNode("servlet-class");
                String servletClass = servletclassElement.getStringValue();


                // 根据servlet-name的值找到url-pattern
                Element servletMapping = (Element) rootElement.selectSingleNode("/web-app/servlet-mapping[servlet-name='" + servletName + "']");
                // /lagou
                String urlPattern = servletMapping.selectSingleNode("url-pattern").getStringValue();
                String[] split = servletClass.split("\\.");
                String result = split[0] + "." + service + "." + split[1];
                System.out.println(result);
                HttpServlet servlet = (HttpServlet) Class.forName(result).newInstance();
                servletMap.put(server + urlPattern, servlet);
            }

        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    /**
     * Minicat 的程序启动入口
     *
     * @param args
     */
    public static void main(String[] args) {
        Bootstrap bootstrap = new Bootstrap();
        try {
            // 启动Minicat
            bootstrap.start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println();
    }

    public String getWorkBase() {
        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("web.xml");
        SAXReader saxReader = new SAXReader();
        String workBase = "";

        try {
            Document document = saxReader.read(resourceAsStream);
            Element rootElement = document.getRootElement();
            workBase = rootElement.selectSingleNode("work-base").getStringValue();
        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return workBase;
    }


    private static void copyFile(String source, String dest, String name) throws IOException {
        File file = new File(dest);
        if (!file.exists()) {
            file.createNewFile();
        }

        InputStream in = new FileInputStream(new File(source));
        OutputStream out = new FileOutputStream
                (file);
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();

        //对包名修改一下
        if (!"".equals(name)) {
            //package servlet; -> package servlet.项目名;

            try {
                ProcessData.changeFile(dest,name);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    //package不对，修改文件内容吧包整全
    public static void updateStartBat(String fileName, String oldstr, String newStr) {
        //把第一行添加上表头
        System.out.println(oldstr + "   " + newStr);


    }
}
