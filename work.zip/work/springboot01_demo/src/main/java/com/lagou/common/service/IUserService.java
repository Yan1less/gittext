package com.lagou.common.service;

public interface IUserService {

    public String sayHello(String smg);

}
