package com.lagou.config;

public class MyService {
}
